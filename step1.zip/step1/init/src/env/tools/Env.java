package tools;

import cartago.*;

public class Env extends Artifact {

	private Display display;
	
    void init() {
    	display = new Display();
    	display.setVisible(true);
    	System.out.println("Env ready.");
	}
    
    @OPERATION void printMsg(String msg){
    	String agentName = this.getCurrentOpAgentId().getAgentName();
    	display.addText("Message from "+agentName+": "+msg);
    }

}
