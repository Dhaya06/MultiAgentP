package tools;

import java.awt.Dimension;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;

public class Display extends JFrame {		
	
	private JTextArea text;
	
	public Display(){
		setTitle(".:: ENVIRONMENT CONSOLE ::.");
		setSize(600,600);
		
		JPanel panel = new JPanel();
		setContentPane(panel);
		
		text = new JTextArea();
		text.setMinimumSize(new Dimension(580,550));
		text.setMaximumSize(new Dimension(580,550));
		text.setPreferredSize(new Dimension(580,550));
		text.setEditable(true);
		
		panel.add(text);
	}
	
	public void addText(final String s){
		SwingUtilities.invokeLater(new Runnable(){
			public void run() {
				text.append(s+"\n");
			}
		});
	}
}